let word = prompt("Welcome to Hangman! Player 1, please enter a word for Player 2 to guess.").toUpperCase();

// note the switch toUpperCase(), we want to always work in upper case letters to avoid confusing 'a' and 'A' as unequal.

/* 
    We will use the 'revealedLetters' array to show that a letter has correctly been guessed.

    The following creates an array with as many elements as the variable word has characters. each index of revealedLetters will correspond to a character in word, and if revealedLetters[n] is truthy, then word[n] has been correctly guessed. 
*/
// To Start revealedLetters = [false,false,false,false,false];
let k = 0;
let count = 0; 
let revealedLetters = new Array(word.length); // creates an array with as many elements as word has characters. Each index of revealedLetters will correspond to a character in word, and if revealedLetters[n] is truthy, then word[n] has been correctly guessed.
revealedLetters.fill(false);
const maxStrikes = 6; 
let strikes = 0; // the number of incorrect guesses made so far

/*
    The strikeLetters array is used to keep track of how many letters were incorrectly guessed by the player and will be used to display those letters to the console
*/

let strikeLetters = new Array(maxStrikes); // this will contain every letter that has been incorrectly guessed.




// Part Two 
let player1 = prompt("Player One Enter Name");
let player2 = prompt("Player Two Enter Name");
console.log("Names are",player1,"&",player2);
/*
    We run 'drawWordProgress' here because this function specifically is used to display the letters guessed, including blank spaces. If your code displays the blank spaces differently, you would not need to run this here.
*/



drawWordProgress(); // run this now, to draw the empty word at the start of the game.





// Manipulates the DOM to write all the strike letters to the appropriate section in hangman.html
function drawStrikeLetters() {
   let strikeRender = "";
   
   if (strikes < maxStrikes) {
       count++

   }

   document.getElementById("strike-draw").innerHTML = count;
   //document.getElementById("strike-letters").innerHTML = strikeLetters;
   

   







}

// Manipulates the DOM to write the successfully guessed letters of the word, replacing them with dashes if not yet guessed
function drawWordProgress() {
    // your DOM manipulation code here
    // should iterate over revealedLetters, and if the value at each index is truthy, print the corresponding letter from word. Otherwise, it should print a -.
        /* 
        This function should update an <img> element in the html file to point to the correct image. The syntax for the reference would be something like:
            "images/strike-"+strikes+".png"
    */
                        let wordToRender = "";

                        for (let i = 0; i < revealedLetters.length; i++) {
                            if (revealedLetters[i]){
                                console.log("Index: " + i + "was True");
                                wordToRender += word[i];
                            } else {
                                console.log("Index: " + i + "was False");
                                wordToRender += "_";
                            }
                        }

                        // More code needed here...
                    
                     document.getElementById("word-draw").innerHTML = wordToRender;
}

// Manipulates the DOM to update the image of the gallows for the current game state.
function drawGallows() { 
    // your DOM manipulation code here 


     document.getElementById("strike-image").src = "images/strike-"+strikes+".png"

}

document.getElementById("submitButton").addEventListener("click", processGuess);
// Part 3
/*
Check Player Input
Verify Whether that input exists inside of our word
If so... Call drawWordProgress
Else... Call drawStrikeLetters & drawGallows
*/
function processGuess(event) {

        // See the last slide on the Week 1, Day 1 powerpoints for detailed information about this.
        event.preventDefault();
       
   
  /*  if (strikes < maxStrikes) {
        // game logic goes here
    } else
        alert("The game is over!"); */

         // IF PLAYER TWO HAS NOT INCORRECTLY GUESSED TOO MANY TIMES
        
    if (strikes < maxStrikes) {
        let guess = document.getElementById("usr-input").value.toUpperCase(); // the value of the <form>'s 
        console.log(guess); 
        //<input> element, toUpperCase()!
        
        let guessCorrect = false;
        for(let i = 0; i< word.length; i++){
            if (guess == word[i]){
                revealedLetters[i] = true;
                guessCorrect = true;
                console.log(revealedLetters);
            }
        }
        if (guessCorrect == true){
            drawWordProgress();
            console.log("YOU'RE CORRECT!!!! :)");
        }
        else {
            strikes++
            drawStrikeLetters();
            drawGallows();
            console.log("YOU'RE WRONG!!! :(")
           strikeLetters[k] = guess; 
            k++ 
        document.getElementById("strike-letters").innerHTML = strikeLetters;
            
        }
    

    } else
    alert("The game is over!");


}


